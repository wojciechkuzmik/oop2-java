public class OptionNotRecognizedException extends Exception {
    public OptionNotRecognizedException(String message){
        super(message);
    }
}
