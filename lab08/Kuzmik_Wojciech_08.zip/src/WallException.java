public class WallException extends Exception{
    public WallException(String message){
        super(message);
    }
}
