interface CheckStep {
    boolean test(char[][] board, int i0, int j0, Direction dir);
}